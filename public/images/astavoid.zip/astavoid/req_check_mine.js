const fs=require("fs");
const nunjucks= require("nunjucks");
const creer_grille=require('./fonction_creer_grille.js');
 


const revealMines = function (grille) {


for (let y=0; y<grille.size; y++){
    for (let x=0; x<grille.size; x++){
        if (grille.board[y][x]==="m"){
        grille.tileClicked[y][x]=true;
        //grille.board[y][x]='<img src="./asteroid.png">';
        }
    }
}
}



const trait = function (req, res, query) {

    
    let marqueurs={};
    let board;
    let x;
    let y;
    
    if (Number(query.x)==NaN || Number(query.y)==NaN){
    return;
    }
    else{
    x=Number(query.x);
    y=Number(query.y);
    }
    
    let numOfMines;
    
    
    function parseBool(val)
{
    if (val === 'true'){
        return true;
        }
    else{
    return false;
}
}
    
    console.log(x)
    console.log(y)	
    
    let contenu_grille = fs.readFileSync("grille.json", 'utf-8');
    console.log(contenu_grille);
    let grille = JSON.parse(contenu_grille);
    
    

    let page= fs.readFileSync('astavoid10x10.html', 'utf-8');
   



function checkBoard(x, y, grille) {

       if (x<0 || x>=grille.size || y<0 || y>=grille.size){
       return 0;
       }    
       if (grille.board[y][x] ==='m'){
       return 1; 
       }
   return 0;
        
};



 
    const checkMine= function (x,y,grille){
  if ( grille.gameOver) {
        
        return ;
     };
     
  if (x < 0 || x >= grille.size || y < 0 || y >=grille.size){
       return ;
    } ; 
    
       
     
        
   if (grille.tileClicked[y][x]){
        return ;
     };
     
   if (grille.board[y][x]==='m'){
   return;
   };
       
       
       
      
       
       grille.tileClicked[y][x]=true;
       
       grille.numClickedTiles += 1;
        
       
       let minesFound = 0;

    
    minesFound += checkBoard(x-1, y-1, grille);      //top left
    minesFound += checkBoard(x-1, y, grille);        //top 
    minesFound += checkBoard(x-1, y+1, grille);      //top  rightt
    minesFound += checkBoard(x, y-1, grille);        //left
    minesFound += checkBoard(x, y+1, grille);        //right
    minesFound += checkBoard(x+1, y-1, grille);      //bottom left
    minesFound += checkBoard(x+1, y, grille);        //bottom 
    minesFound += checkBoard(x+1, y+1, grille);      //bottom right
    
   
    
    
    
    
    
    if ( minesFound> 0) {
        
        grille.board[y][x]= minesFound;
        grille.tileClicked[y][x]=true;
        return minesFound;
             
    }
    
    else {
         if (minesFound==0) {
         grille.board[y][x]='';
         }
         
        checkMine(x-1, y-1, grille);    //top left
        checkMine(x-1, y, grille);      //top
        checkMine(x-1, y+1, grille);    //top right
        checkMine(x, y-1, grille);      //left
        checkMine(x, y+1, grille);      //right
        checkMine(x+1, y-1, grille);    //bottom left
        checkMine(x+1, y, grille);      //bottom
        checkMine(x+1, y+1, grille);    //bottom right
   }
     
     if (Number(grille.numClickedTiles) === ((Math.pow(Number(grille.size),2))-Number(grille.minesCount))) {
        //minesCount = "Cleared";
       grille.gameOver= true;
      page=fs.readFileSync("pageGagne.html",'utf-8')
    }
   
  

};

 if ( grille.board[y][x] === 'm') {
       
       grille.tileClicked[y][x]=true;
       revealMines(grille);
       grille.gameOver=true;
     }

 else{
   grille.board[y][x]=checkMine(x,y,grille); 
    }
    
    
    let tilesLeft=Math.pow(Number(grille.size),2)-Number(grille.minesCount);
    tilesLeft=(Math.pow(Number(grille.size),2)-Number(grille.minesCount)) - Number(grille.numClickedTiles);
        if (tilesLeft===0){
        page=fs.readFileSync('pageGagne.html','utf-8')
        };
        
        if (grille.rocketEnabled==true) {

        if (grille.board[y][x]==0 && grille.tileClicked[y][x]==false) {
            marqueurs.board[y][x] = '<img src = "./ajk.png">';
        }
        else if (marqueurs.board[y][x]= '<img src = "./ajk.png">') {
            grille.board[y][x]= 0;
        }
        return;
    }
    
    let remainingTiles;
    marqueurs.remainingTiles=tilesLeft;
    
    marqueurs.board = grille.board;
    
    let gameOver;
    marqueurs.gameOver=grille.gameOver
    marqueurs.isTileClicked = grille.tileClicked;
    marqueurs.size = grille.size;
    marqueurs.minesCount = grille.minesCount;
    let isRocketEnabled;
    console.log(query.rocketEnabled);
    grille.rocketEnabled = parseBool(query.rocketEnabled);
    marqueurs.isRocketEnabled = grille.rocketEnabled 
    let rocketBackgroundColor;
    
    //marqueurs.numofMines= numMines;
     
    page = nunjucks.renderString(page, marqueurs);
    
    contenu_grille = JSON.stringify(grille);
    fs.writeFileSync('grille.json', contenu_grille, 'utf-8');
 
    res.writeHead(200, { 'Content-Type': 'text/html' });
	res.write(page);
	res.end(); 
 };
module.exports = trait;

